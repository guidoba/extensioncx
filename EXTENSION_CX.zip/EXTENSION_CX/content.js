(() => {
  'use strict';

  // Tarifario real de delivery. Actualizar manualmente estos importes cuando cambien.
  const DELIVERY_PRICES = Object.freeze({
    'Delivery 2k': 8000,
    'Delivery 5k': 10000,
    'Delivery 8k': 12000,
    'Delivery 11k': 15000,
    'Delivery 14k': 16000
  });
  const DELIVERY_BARCODE = '7664422101023';
  const rowControllers = new WeakMap();
  let observerTimer = 0;

  const normalize = (value) => value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

  const formatGs = (amount) => `Gs. ${Math.max(0, Math.round(amount)).toLocaleString('es-PY').replace(/,/g, '.')}`;

  function parseGs(value) {
    const digits = String(value || '').replace(/[^0-9]/g, '');
    return digits ? Number(digits) : 0;
  }

  function parseQuantity(value) {
    const match = String(value || '').replace(',', '.').match(/\d+(?:\.\d+)?/);
    return match ? Math.max(1, Math.floor(Number(match[0]))) : 1;
  }

  function getColumnMap(table) {
    const headerRow = table.querySelector('thead tr');
    if (!headerRow) return null;
    const headers = Array.from(headerRow.children);
    const map = {};
    headers.forEach((header, index) => {
      const text = normalize(header.textContent);
      if (text.includes('nombre')) map.name = index;
      if (text.includes('codigo') && text.includes('barras')) map.sku = index;
      if (text === 'precio' || text.startsWith('precio ')) map.price = index;
      if (text.includes('empaquetado')) map.packed = index;
      if (text.includes('cantidad pedida')) map.ordered = index;
      if (text === 'acciones' || text.startsWith('acciones ')) map.actions = index;
    });
    return map.name !== undefined && map.price !== undefined ? map : null;
  }

  function getCell(row, index) {
    return index === undefined ? null : row.children[index] || null;
  }

  function createCopyIcon(button) {
    button.textContent = '';
    button.setAttribute('aria-label', 'Copiar producto');
    button.title = 'Copiar producto';
    const icon = document.createElement('span');
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = '📋';
    button.appendChild(icon);
  }

  function getRowData(controller) {
    const { row, columnMap } = controller;
    const nameCell = getCell(row, columnMap.name);
    const skuCell = getCell(row, columnMap.sku);
    const priceCell = getCell(row, columnMap.price);
    const packedCell = getCell(row, columnMap.packed);
    const orderedCell = getCell(row, columnMap.ordered);
    const name = nameCell?.textContent.trim() || '';
    const sku = skuCell?.textContent.trim() || '';
    const shownPriceText = priceCell?.textContent.trim() || '';
    const shownPrice = parseGs(shownPriceText);
    const originalQuantity = parseQuantity(packedCell?.textContent || orderedCell?.textContent || '1');
    const isDelivery = name.startsWith('Delivery');
    const tariffPrice = DELIVERY_PRICES[name];
    return {
      name,
      sku,
      shownPriceText,
      shownPrice,
      originalQuantity,
      isDelivery,
      tariffPrice,
      effectivePrice: controller.deliveryToggle?.checked && tariffPrice ? tariffPrice : shownPrice,
      effectiveQuantity: controller.quantitySelect ? Number(controller.quantitySelect.value) : originalQuantity
    };
  }

  function buildCopyText(data, includeTotal = true) {
    const lines = [
      `Producto: ${data.name}`,
      `SKU: ${data.sku || DELIVERY_BARCODE}`,
      `Cantidad: ${data.effectiveQuantity}`,
      `Precio: ${formatGs(data.effectivePrice)}`
    ];
    if (includeTotal) lines.push('', `TOTAL: ${formatGs(data.effectivePrice * data.effectiveQuantity)}`);
    return lines.join('\n');
  }

  function flashCopyButton(button, originalText = '📋') {
    button.classList.add('cx-copied');
    button.textContent = '✓';
    window.setTimeout(() => {
      if (button.isConnected) {
        button.classList.remove('cx-copied');
        button.textContent = originalText;
      }
    }, 1500);
  }

  async function copyRow(controller) {
    const data = getRowData(controller);
    try {
      await navigator.clipboard.writeText(buildCopyText(data));
      flashCopyButton(controller.copyButton);
    } catch (error) {
      console.error('[Extensión CX] No se pudo copiar la fila:', error);
    }
  }

  function makeQuantitySelect(controller, cell) {
    if (controller.quantitySelect || controller.data.originalQuantity <= 1) return;
    const select = document.createElement('select');
    select.className = 'cx-quantity';
    select.setAttribute('aria-label', 'Cantidad a copiar');
    for (let quantity = 1; quantity <= controller.data.originalQuantity; quantity += 1) {
      const option = document.createElement('option');
      option.value = String(quantity);
      option.textContent = String(quantity);
      select.appendChild(option);
    }
    select.value = String(controller.data.originalQuantity);
    select.addEventListener('change', updatePanel);
    controller.quantitySelect = select;
    cell.appendChild(select);
  }

  function makeDeliveryToggle(controller, cell) {
    if (controller.deliveryToggle || !controller.data.isDelivery || controller.data.shownPrice > 1000) return;
    const tariffPrice = DELIVERY_PRICES[controller.data.name];
    if (!tariffPrice) return;
    const wrapper = document.createElement('label');
    wrapper.className = 'cx-delivery-wrap';
    wrapper.title = `Alternar entre ${formatGs(controller.data.shownPrice)} y ${formatGs(tariffPrice)}`;
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.setAttribute('aria-label', 'Usar monto original del tarifario');
    const text = document.createElement('span');
    text.textContent = 'Monto original';
    input.addEventListener('change', updatePanel);
    wrapper.append(input, text);
    controller.deliveryToggle = input;
    cell.appendChild(wrapper);
  }

  function addRowControls(controller) {
    const { row, columnMap } = controller;
    if (row.dataset.cxEnhanced === 'true') return;
    row.dataset.cxEnhanced = 'true';
    row.dataset.cxRow = 'true';

    const firstCell = row.children[0];
    const toolCell = getCell(row, columnMap.actions) || getCell(row, columnMap.name) || firstCell;
    if (!firstCell || !toolCell) return;

    const tools = document.createElement('span');
    tools.className = 'cx-row-tools';

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'cx-select-row';
    checkbox.setAttribute('aria-label', 'Seleccionar producto');
    checkbox.addEventListener('change', updatePanel);

    const copyButton = document.createElement('button');
    copyButton.type = 'button';
    copyButton.className = 'cx-copy-row';
    createCopyIcon(copyButton);
    copyButton.addEventListener('click', () => copyRow(controller));

    controller.checkbox = checkbox;
    controller.copyButton = copyButton;
    tools.append(checkbox, copyButton);
    toolCell.insertBefore(tools, toolCell.firstChild);

    makeQuantitySelect(controller, tools);
    makeDeliveryToggle(controller, tools);
  }

  function refreshController(controller, columnMap) {
    controller.columnMap = columnMap;
    controller.data = getRowData(controller);
    if (controller.quantitySelect && controller.data.originalQuantity <= 1) {
      controller.quantitySelect.remove();
      controller.quantitySelect = null;
    } else if (!controller.quantitySelect) {
      makeQuantitySelect(controller, controller.row.querySelector('.cx-row-tools'));
    }
    if (!controller.deliveryToggle) {
      makeDeliveryToggle(controller, controller.row.querySelector('.cx-row-tools'));
    }
    if (controller.copyButton) {
      controller.copyButton.title = `Copiar producto. Total: ${formatGs(controller.data.effectivePrice * controller.data.effectiveQuantity)}`;
    }
  }

  function processTable(table, columnMap) {
    const body = table.tBodies[0];
    if (!body) return;
    const rows = Array.from(body.children).filter((element) => element.tagName === 'TR');
    let detected = 0;
    rows.forEach((row) => {
      const existing = rowControllers.get(row);
      const controller = existing || { row, columnMap };
      controller.columnMap = columnMap;
      controller.data = getRowData(controller);
      if (!controller.data.name || !controller.data.shownPriceText) return;
      detected += 1;
      if (!existing) rowControllers.set(row, controller);
      addRowControls(controller);
      refreshController(controller, columnMap);
    });
    // console.log(`[Extensión CX] Filas detectadas: ${detected}; filas en DOM: ${rows.length}`);
  }

  function getSelectedControllers() {
    return Array.from(document.querySelectorAll('tr[data-cx-row="true"]'))
      .map((row) => rowControllers.get(row))
      .filter((controller) => controller?.checkbox?.checked && controller.row.isConnected);
  }

  function ensurePanel() {
    let panel = document.getElementById('cx-copy-panel');
    if (panel) return panel;
    panel = document.createElement('aside');
    panel.id = 'cx-copy-panel';
    panel.innerHTML = '<button type="button" id="cx-copy-selected">Copiar seleccionados (0)</button><div id="cx-copy-total">Total: Gs. 0</div>';
    document.body.appendChild(panel);
    panel.querySelector('button').addEventListener('click', copySelected);
    return panel;
  }

  function updatePanel() {
    const selected = getSelectedControllers();
    const panel = ensurePanel();
    const button = panel.querySelector('button');
    const total = selected.reduce((sum, controller) => {
      controller.data = getRowData(controller);
      return sum + controller.data.effectivePrice * controller.data.effectiveQuantity;
    }, 0);
    button.textContent = `Copiar seleccionados (${selected.length})`;
    panel.querySelector('#cx-copy-total').textContent = `Total: ${formatGs(total)}`;
    panel.classList.toggle('cx-visible', selected.length > 0);
  }

  async function copySelected() {
    const selected = getSelectedControllers();
    if (!selected.length) return;
    const blocks = selected.map((controller) => buildCopyText(getRowData(controller), false));
    const total = selected.reduce((sum, controller) => {
      const data = getRowData(controller);
      return sum + data.effectivePrice * data.effectiveQuantity;
    }, 0);
    try {
      await navigator.clipboard.writeText(`${blocks.join('\n\n')}\n\nTOTAL: ${formatGs(total)}`);
      const button = document.querySelector('#cx-copy-selected');
      button.textContent = '¡Copiado!';
      window.setTimeout(() => {
        if (button.isConnected) button.textContent = `Copiar seleccionados (${getSelectedControllers().length})`;
      }, 1500);
    } catch (error) {
      console.error('[Extensión CX] No se pudo copiar la selección:', error);
    }
  }

  function scan() {
    document.querySelectorAll('table').forEach((table) => {
      const columnMap = getColumnMap(table);
      if (columnMap) processTable(table, columnMap);
    });
    updatePanel();
  }

  function scheduleScan() {
    window.clearTimeout(observerTimer);
    observerTimer = window.setTimeout(scan, 100);
  }

  const observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  scan();
})();
